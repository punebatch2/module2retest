package com.capgemini.pizzaorder.bean;

enum vegToppings {
	
	capsicum  , mushroom  , jalepeno  , paneer 

};
