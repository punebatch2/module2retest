package com.capgemini.pizzaorder.dao;

import java.sql.SQLException;

import com.capgemini.pizzaorder.bean.Customer;
import com.capgemini.pizzaorder.bean.Pizza;
import com.capgemini.pizzaorder.exception.PizzaException;

public interface IPizzaOrderDao {
	
	public int placeOrder(Customer customer, Pizza pizza) throws PizzaException, SQLException;
	
	public Pizza displayOrder(int orderId) throws PizzaException, SQLException;

}
