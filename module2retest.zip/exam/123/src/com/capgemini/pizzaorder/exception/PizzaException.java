package com.capgemini.pizzaorder.exception;

public class PizzaException extends Exception {

	public PizzaException() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
