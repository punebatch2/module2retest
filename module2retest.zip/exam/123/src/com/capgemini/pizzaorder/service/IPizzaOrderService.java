package com.capgemini.pizzaorder.service;

import java.sql.SQLException;

import com.capgemini.pizzaorder.bean.Customer;
import com.capgemini.pizzaorder.bean.Pizza;
import com.capgemini.pizzaorder.exception.PizzaException;

public interface IPizzaOrderService {

public int placeOrder(Customer customer, Pizza pizza) throws PizzaException, SQLException;
	
	public Pizza displayOrder(int orderId) throws PizzaException, SQLException;

	public boolean isValidMobile(String phoneNo) throws PizzaException;



	
		
	
}
