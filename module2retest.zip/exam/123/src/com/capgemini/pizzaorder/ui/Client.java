package com.capgemini.pizzaorder.ui;

import java.sql.SQLException;
import java.util.Date;
import java.util.Scanner;

import com.capgemini.pizzaorder.bean.Customer;
import com.capgemini.pizzaorder.bean.Pizza;
import com.capgemini.pizzaorder.dao.IPizzaOrderDao;
import com.capgemini.pizzaorder.dao.PizzaOrderDao;
import com.capgemini.pizzaorder.exception.PizzaException;
import com.capgemini.pizzaorder.service.IPizzaOrderService;
import com.capgemini.pizzaorder.service.PizzaOrderService;

public class Client {

	public static Scanner sc = new Scanner(System.in);
	public static IPizzaOrderDao pizzaOrder = new PizzaOrderDao();
	public static IPizzaOrderService pizzaService = new PizzaOrderService();
	
	public static void main(String[] args) throws PizzaException, SQLException {
		
		Pizza pizza = new Pizza();
		Customer customer = new Customer();
		
		while (true) 
		{

			// show menu
			System.out.println();
			System.out.println();
			System.out.println(" Welcome to JustEatPizzas ");
			System.out.println("_______________________________\n");
			System.out.println("1.Place an order ");
			System.out.println("2. Display order");
			System.out.println("3.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			
			int choice = sc.nextInt();
			
			switch(choice)
			{
			
				case 1:
					
					double price = 0.0;
					
					System.out.println();
					System.out.println();
					System.out.println("Hie, now enter your details");
					System.out.println("Enter the name of your customer");
					String custN = sc.next();
					customer.setCustName(custN);
					
					System.out.println("Enter customer Address");
					String address = sc.next();
					customer.setCustAddress(address);
					
					System.out.println("Enter customer phone number");
					String phoneNo = sc.next();
					if(pizzaService.isValidMobile(phoneNo) == true) {
						customer.setPhoneNo(phoneNo);
					}
					
//					Two possibilities, i) i dont know how to work on dates
//									   ii) ojdbc wasnt compatible with the computer i was using
					
//					debug required!!

					pizza.setOrderDate(new Date());
					
//					pizza.setOrderDate("08-11-2018");
					
					System.out.println("Enter type of pizza topping preffered");
					System.out.println("capsicum {30} , mushroom {50} , jalepeno {70} , paneer(bhot mehnga he bhaai) {85}");
					String topping = sc.next();
					
					System.out.println("Your total price is ");
					
					if(topping.equals("capsicum"))
					{
						
						price = 350+30 + (0.04*(380));
						pizza.setTotalPrice(price);
						
					}
					
					else if(topping.equals("mushroom"))
					{
						
						price = 350+50 + (0.04*(400));
						pizza.setTotalPrice(price);
						
					}
					else if(topping.equals("jalepeno"))
					{
						
						price = 350+70 + (0.04*(420));
						pizza.setTotalPrice(price);
						
					}
					
					else if(topping.equals("paneer"))
					{
						
						price = 350+85 + (0.04*(435));
						pizza.setTotalPrice(price);
						
					}
					else
					{
						System.out.println("Enter a proper topping..");
					}
					System.out.println(price);
					
					int orderId = pizzaOrder.placeOrder(customer, pizza);
					
					System.out.println("Your order Id is " + orderId);
					
					break;
					
				case 2 :
					
					System.out.println();
					System.out.println();
				
					System.out.println("Enter your order Id");
					int id = sc.nextInt();
					
					Pizza pizza1 = pizzaOrder.displayOrder(id);
					
					System.out.println("your orderId is " + id);
//					System.out.println("Customer Id is " + pizza.getCustomer().getCustomerId());
					System.out.println("Total price " + pizza1.getTotalPrice());
					System.out.println("Order Date " + pizza1.getOrderDate());
					
					break;
					
					
				case 3 :
					System.exit(0);
				default : System.out.println("Enter valid option");
							break;	
				
			}
				
		
		
	}
	}
}
	
	

