package com.cg.pizzaorder.service;

import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;

public interface IPizzaOrderService 
{
	public int placeOrder(Customer customer,PizzaOrder pizza) throws PizzaException;
	public PizzaOrder displayOrder(int orderid) throws PizzaException;
	public double Calculateprice(PizzaOrder pizza);

}
